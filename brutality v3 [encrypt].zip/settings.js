//===========================//
global.prefa = ['','!','.',',','🐤','🗿']
//===========================//
global.owner = ['6283841442290']
global.botname = 'Brutality Bot'
//===========================//
global.versionsc = "3.0"
global.baileys1 = require('@whiskeysockets/baileys')
//===========================//
global.packname = "Sticker By"
global.author = "Dika ID"
//===========================//